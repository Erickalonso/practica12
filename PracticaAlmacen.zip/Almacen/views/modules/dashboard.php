<?php
	
	session_start();
	if(!$_SESSION['user']){
		echo "
		<script type='text/javascript'>
			window.location='index.php';
		</script>";
	}	

	$MVC = new MvcController();
?>
<div class="content-wrapper">
	<h2>Inicio<i class="nav-icon  fa fa-home"></i></h2>
	<div class="row">
		<!--<div class="col-lg-12 col-12">
			<div class="card card-widget widget-user">
			  	<div class="widget-user-header bg-info-active" >
			    	<h3 class="widget-user-username"><?php  $MVC->userInfoController(); ?></h3>
			  	</div>
			  	<div class="widget-user-image">
			    	<img class="img-circle elevation-2" src="views/dist/img/user.png" alt="User Avatar">
			  	</div>
			  	<div class="card-footer">
			    	<div class="row">
			    	 	<div class="col-sm-12 border-right">
			        		<div class="description-block">
			          			<h5 class="description-header"><?php  $MVC-> viewUserHistorialController();?></h5>
			          			<span class="description-text">Movimientos Realizados</span>
			        		</div>
			       
			      		</div>
			     
			    	</div>
			    
			  	</div>
			</div>
		</div>-->
		<div class="col-lg-6 col-12">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>Productos <label class="nav-icon fa fa-cubes"></label></h3>
					<h4>Total: <?php  $MVC ->countProductController();  ?></h4>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-12">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>Usuarios <label class="nav-icon fa fa-users"></label></h3>
					<h4>Total: <?php $MVC -> countUserController();?></h4>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-12">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>Categorias <label class="nav-icon fa fa-tag"></label></h3>
					<h4>Total: <?php $MVC -> countCategoryController();?></h4>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-12">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>Movimientos <label class="nav-icon fa fa-book"></label></h3>
					<h4>Total: <?php $MVC-> countHistorialController();  ?></h4>
				</div>
			</div>
		</div>
	</div>
</div>


