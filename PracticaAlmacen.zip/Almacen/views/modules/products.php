<?php
	
	session_start();
	if(!$_SESSION['user']){
		echo "
		<script type='text/javascript'>
			window.location='index.php';

		</script>";
	}	

	$MVC = new MvcController();
?>
<div class="content-wrapper">
	<div class="card card-info">
	    <div class="card-header">
	        <a href="index.php?action=products"><b class="card-title">Productos</b></a>
	       
	    </div>
	        <!-- /.card-header -->
	    <div class="card-body">
			<table id="example1" class="table table-bordered table-striped">
	            <thead>
					<tr>
						<th>ID</th>
						<th>Codigo</th>
						<th>Nombre</th>
						<th>Fecha de registro</th>
						<th>Precio</th>
						<th>Stock</th>
						<th>Categoria</th>
						<?php
						if($_SESSION["user"]==1){
						?>
							<th></th>
							<th></th>
							<th></th>
						<?php
						}else{
						?>
							<th></th>
						<?php
						}	
						?>
					</tr>
				</thead>
				<tbody>
				<?php
					$MVC -> productViewsController();
				?>
				</tbody>
	        </table>
	    </div>
	</div>
</div>

