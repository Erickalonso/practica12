<?php
	session_start();
	if(!$_SESSION['user']){
		echo "
		<script type='text/javascript'>
			window.location='index.php';
		</script>";
	}	
	$MVC = new MvcController();
?>

<div class="content-wrapper">
	<section class="content">
	    <div class="container-fluid">
	    	<div class="row">
	    		<div class="col-6">
		        	<div class="card">
		          		<div class="card-header">
		            		<label class="card-title">Eliminar Usuario</label>

		          		</div>
		      		
						<form method="post" role="form">
							<div class="card-body" align="center">
									<h3>Ingresa tu contraseña para eliminar el producto</h3>
									<div class="col-4"></div>
									<div class="col-4">
										<input type="password" name="password" placeholder="Contraseña" class="form-control" required><br>
									</div>
									<div class="col-4"></div>
									<input type="submit" name="delete" value="Aceptar" class="btn btn-info" onclick="alertaEliminar()">
									<a href="index.php?action=users"><input type="button" name="cancelar" value="Cancelar" class="btn btn-secondary"></a>
							</div>	
						</form>
						<?php
							$MVC->deleteUserController();
						?>
					</div>
				</div>

          	</div>
		</div>
	</section>
</div>

<script type="text/javascript">
      //Funcion para escribir una alerta y validar si se desaea o no se desea eliminarlo
      function alertaEliminar(){
        var alerta = confirm("Seguro que desea eliminarlo?");
        if(alerta == false){
            event.preventDefault();
        }
      }
    </script>