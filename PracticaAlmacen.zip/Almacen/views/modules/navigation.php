<?php
	$MVC = new MvcController();
  session_start();

 
?>
<body style="background-color:#efefef" align="center">
	<nav class="main-header navbar navbar-expand bg-gray navbar-dark border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      	<li class="nav-item">
        	<a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      	</li>
    </ul>
	</nav>

	<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php?action=dashboard" class="brand-link">
      
      <span class="brand-text font-weight-light">Control de almacén</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="views/dist/img/user.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php $MVC -> userInfoController(); echo'<br> Movimientos: '; $MVC->viewUserHistorialController();?></a>
        </div>
      </div>
      <!-- Sidebar user panel (optional) -->
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

          <?php
              if($_SESSION["user"]==1){


          ?>
          <li class="nav-item">
            <a href="index.php?action=dashboard" class="nav-link">
              <i class="nav-icon  fa fa-home"></i>
              <p>
                Inicio
              </p>
            </a>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-user"></i>
              <p>
                Usuarios
                <i class="fa fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="index.php?action=users" class="nav-link">
                  
                  <p>Ver Usuarios</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?action=addUser" class="nav-link">
                  
                  <p>Agregar Usuario</p>
                </a>
              </li>
            </ul>
          </li>


          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-cube"></i>
              <p>
                Inventario
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="index.php?action=products" class="nav-link">
                 
                  <p>Ver Productos</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?action=addProduct" class="nav-link">
                  
                  <p>Agregar Producto</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-tag"></i>
              <p>
               	Categorias
                <i class="fa fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="index.php?action=categories" class="nav-link">
                  
                  <p>Ver Categorias</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?action=addCategory" class="nav-link">
                  
                  <p>Agregar Categoria</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="index.php?action=logout" class="nav-link">
              
              <p>
                Salir
              </p>
            </a>
          </li>
          <?php
            }else{


          ?>
            <li class="nav-item">
            <a href="index.php?action=dashboard" class="nav-link">
              <i class="nav-icon  fa fa-home"></i>
              <p>
                Inicio
              </p>
            </a>
          </li>

           <li class="nav-item">
            <a href="index.php?action=users" class="nav-link">
              <i class="nav-icon fa  fa-users"></i>
              <p>
                Usuarios
              </p>
            </a>
          </li>


           <li class="nav-item">
            <a href="index.php?action=products" class="nav-link">
              <i class="nav-icon fa  fa-cubes"></i>
              <p>
                Productos
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="index.php?action=categories" class="nav-link">
              <i class="nav-icon fa  fa-tag"></i>
              <p>
                Categorias
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php?action=logout" class="nav-link">
              
              <p>
                Salir
              </p>
            </a>
          </li>


          <?php
            }
          ?>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
</body>